<?php

return [
    'dash' => 'Dashboard',
    'profile' => 'Profile',
    'settings' => 'Settings',
    'logout' => 'Logout' ,
    'add'=> 'Add',
    'addC'=> 'Add Country',
    'newC'=>'Add New Country',
    'country' =>'Country name',
    'update'=>'Update ',
    'addCity'=>'Add City'
];
