<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* تنسيق الجدول */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        /* تخصيص الألوان */
        body {
            background-color: #f9f9f9;
            font-family: Arial, sans-serif;
        }

        h1 {
            text-align: center;
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Hotels </h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Price </th>
                <th>Amount</th>
                <th>Length </th>
                <th>Width</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item['id']); ?></td>
                <td><?php echo e($item['price']); ?></td>
                <td><?php echo e($item['amount']); ?></td>
                <td><?php echo e($item['length']); ?> </td>
                <td><?php echo e($item['width']); ?> </td>
            </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>



<?php /**PATH C:\xampp\htdocs\Hotel\resources\views/admin/room_type/pdf.blade.php ENDPATH**/ ?>