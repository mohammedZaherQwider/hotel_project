<?php $__env->startSection('content'); ?>
    <body>
        <!-- Page Content -->
        <div class="container">
            <h1 class="mt-4 mb-3"><?php echo e($room->name); ?>

            </h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('admin.hotels.index')); ?>">Home</a>
                </li>
                <li class="breadcrumb-item active">Room deatiles</li>
            </ol>
            <div class="row">
                <!-- Post Content Column -->
                <div class="col-lg-8">
                    <?php
                        foreach ($images as  $img) {
                            $im= $img->image;
                        }
                    ?>
                    <!-- Preview Image -->
                    <img class="img-fluid rounded" src="<?php echo e(asset($im)); ?>" alt="">
                    <hr>
                    <!-- Date/Time -->
                    <p>Posted on <?php echo e($room->created_at); ?></p>
                    <hr>
                    <!-- Post Content -->
                    <p class="lead">Descripitoin :<?php echo e($room->descripitoin); ?></p>
                    <p class="lead"> id of room type :<?php echo e($room->room_type_id); ?></p>
                    <p class="lead">Hotel id <?php echo e($room->hotel_id); ?></p>
                    <hr>
                </div>
                <!-- Sidebar Widgets Column -->

            </div>
            <!-- /.row -->
        </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hotel\resources\views/admin/room/show.blade.php ENDPATH**/ ?>