<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ddd;
            margin-top: 20px;
            border: 1px solid #00b300;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #22e5c8;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e0e0e0;
        }

        .action-column {
            width: 100px;
        }

        .action-btn {
            display: inline-block;
            margin-right: 5px;
            padding: 5px;
            border: none;
            background-color: #f2f2f2;
            color: #333;
            cursor: pointer;
            font-size: 14px;
            border-radius: 7px;
            width:50px;
        }

        .edit-btn {
            background-color: #ffc107;
        }

        .delete-btn {
            background-color: #ee192f;
        }
        .fas{
            color: #ffffff
        }
    </style>
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Country id</th>
                <th>Country name</th>
                <th class="action-column">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($country->id); ?></td>
                    <td><?php echo e($country->name); ?></td>
                    <td class="action-column">
                        <button class="action-btn edit-btn"><i class="fas fa-pencil-alt"></i></button>
                        <button class="action-btn delete-btn"><i class="fas fa-trash-alt"></i></button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- يمكنك إضافة المزيد من الصفوف هنا -->
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hotel\resources\views/admin/allCountries.blade.php ENDPATH**/ ?>