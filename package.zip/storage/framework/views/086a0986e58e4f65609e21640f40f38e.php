<?php $__env->startSection('content'); ?>
    

    <?php
        $r = Auth::guard('admin')->user()->image->image;
    ?>
    <h1>Ad min Index page</h1>
    <div class="col-12">
        <div class="kt-portlet kt-portlet--mobile">
            <div class="kt-portlet__head kt-portlet__head--lg">
                <div class="kt-portlet__head-label">
                    
                    <h3 class="kt-portlet__head-title">
                        Your Profile
                    </h3>
                </div>
            </div>
            <div class="kt-portlet__body">

                <form action="<?php echo e(route('admin.profile')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo e(Auth::guard('admin')->user()->name); ?>"
                            class="form-control" style="width: 50%" />
                    </div>
                    <div class="">
                        <div class="mb-3 dropzone" id="dropimage" style="width: 50%;">
                        </div>

                    </div>

                    
                    <input type="hidden" value="" id="img" name="img">
                    <button class="btn btn-success"><i class="fas fa-save"></i> Update</button>
                </form>
                        <div class="admin_img_wrapper" style="margin: 20px;" >
                            <img class="img-profile" src="<?php echo e(asset("storage/$r")); ?>" height="200px" width="200px">
                        </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admin.dropzone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hotel\resources\views/admin/adminIndex.blade.php ENDPATH**/ ?>