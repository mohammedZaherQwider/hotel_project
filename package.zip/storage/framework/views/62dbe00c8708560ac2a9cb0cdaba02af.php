<script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
<link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />

<script>
    let myDropzone = new Dropzone("#dropimage", {
        url: "<?php echo e(route('admin.profile_image')); ?>",
        headers: {
            'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
        },
        success: function(file, res) {
            console.log(res.url);
            $('#img').val(res.url);
            $('.admin_img_wrapper').html(img)

        }
    });
</script>
<?php /**PATH C:\xampp\htdocs\Hotel\resources\views/admin/dropzone.blade.php ENDPATH**/ ?>