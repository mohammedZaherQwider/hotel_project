<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فندق المثال</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.5.2/dist/css/bootstrap.min.css">
    <style>
        /* أنماط تخصيصية إضافية هنا */
        .hotel-image {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <header>
        <!-- شريط التنقل هنا -->
    </header>

    <section class="container mt-5">
        <div class="row">
            <div class="col-md-6">
                <h1>فندق المثال</h1>
                <p>استمتع بإقامة رائعة معنا في فندقنا الفخم.</p>
                <button class="btn btn-primary">احجز الآن</button>
            </div>
            <div class="col-md-6">
                <img src="hotel-image.jpg" alt="صورة الفندق" class="hotel-image">
            </div>
        </div>
    </section>

    <section class="container mt-5">
        <h2>غرفنا</h2>
        <div class="row">
            <div class="col-md-4">
                <img src="room1.jpg" alt="غرفة فاخرة">
                <h3>غرفة فاخرة</h3>
                <p>استمتع بالإقامة في غرفتنا الفاخرة مع إطلالة خلابة على المدينة.</p>
            </div>
            <div class="col-md-4">
                <img src="room2.jpg" alt="غرفة عائلية">
                <h3>غرفة عائلية</h3>
                <p>تمتع بعطلة عائلية ممتعة في غرفتنا العائلية الواسعة والمريحة.</p>
            </div>
            <div class="col-md-4">
                <img src="room3.jpg" alt="غرفة ديلوكس">
                <h3>غرفة ديلوكس</h3>
                <p>استرخِ واستمتع بالفخامة في غرفتنا الديلوكس الفسيحة والمجهزة بأعلى مستوى.</p>
            </div>
        </div>
    </section>

    <footer class="bg-light text-center py-3">
        <div class="container">
            <p>جميع الحقوق محفوظة © 2023 فندق المثال</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Hotel\resources\views/index.blade.php ENDPATH**/ ?>