<?php $__env->startSection('content'); ?>
    <body>
        <!-- Page Content -->
        <div class="container">
            <h1 class="mt-4 mb-3"><?php echo e($hotel->name); ?>

            </h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('admin.hotels.index')); ?>">Home</a>
                </li>
                <li class="breadcrumb-item active">Hotel deatiles</li>
            </ol>
            <div class="row">
                <!-- Post Content Column -->
                <div class="col-lg-8">
                    <?php
                        foreach ($images as  $img) {
                            $im= $img->image;
                        }
                    ?>
                    <!-- Preview Image -->
                    <img class="img-fluid rounded" src="<?php echo e(asset($im)); ?>" alt="">
                    <hr>
                    <!-- Date/Time -->
                    <p>Posted on <?php echo e($hotel->created_at); ?></p>
                    <hr>
                    <!-- Post Content -->
                    <p class="lead"><?php echo e($hotel->descripitoin); ?></p>
                    <hr>
                </div>
                <!-- Sidebar Widgets Column -->

            </div>
            <!-- /.row -->
        </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hotel\resources\views/admin/hotel/show.blade.php ENDPATH**/ ?>